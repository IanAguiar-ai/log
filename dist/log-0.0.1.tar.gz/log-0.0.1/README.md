# Log
Class to facilitate log creation